from django.shortcuts import render,redirect
import random
from datetime import datetime

def index(request):
    if 'gold' not in request.session:
        request.session['gold']=0
    if 'message' not in request.session:
        request.session['message'] = []
    context=  {
        'gold': request.session['gold'],
        'message': request.session['message'],
    }
    return  render(request, 'ninja_app/index.html',context)

def farm (request):
    if 'gold' not in request.session:
        request.session['gold']= 0
    if 'message' not in request.session:
        request.session['message'] =[]

    if request.method == 'POST':
        value = request.POST['choice']
        if value == 'farm':
            coins =random.randint(10,20)
            print(datetime.now())
            print(request.session['gold'])
            request.session ['gold'] +=coins
            request.session['message'].insert(0,['earn'+ str(coins)+ 'in farm at' + str (datetime.now()), 'blue'])
            print ('+', coins,'=', request.session ['gold'], '\n', "**"*20)
        if value == 'cave':
            coins = random.randint (5,10)
            print (request.session ['gold'])
            request.session['gold']+=coins
            request.session['message'].insert(0,['earn ' + str(coins)+ ' in cave at '+ str(datetime.now()),'blue'])
            print('+',coins,'= ',request.session['gold'], '\n',"*"*40)
        if value  == 'house':
            coins = random.randint(2,5)
            print(request.session['gold'])
            request.session['gold'] += coins
            request.session['message'].insert(0,['earn ' + str(coins)+ ' in house at '+ str(datetime.now()),'blue'])
            print('+',coins,'= ',request.session['gold'], '\n',"*"*40)
        if value  == 'casino':
            x = random.randint(1,2)
            if x == 1:
                coins = random.randint(0,50)
                print(request.session['gold'])
                request.session['gold'] += coins
                request.session['message'].insert(0,['earn ' + str(coins)+ ' in casino at '+ str(datetime.now()),'blue'])
                print('+',coins,'= ',request.session['gold'], '\n',"*"*40)
            if x == 2:
                coins = random.randint(0,50)
                print(request.session['gold'])
                request.session['gold'] -= coins
                request.session['message'].insert(0,['take ' + str(coins)+ ' in casino at '+ str(datetime.now()),'red'])
                print('+',coins,'= ',request.session['gold'], '\n',"*"*40)
    return redirect('/')
def reset1(request):
    request.session.pop('gold')
    request.session.pop('message')
    return redirect ('')
